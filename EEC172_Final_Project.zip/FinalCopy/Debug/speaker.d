# FIXED

speaker.obj: ../speaker.c
speaker.obj: ../speaker.h
speaker.obj: ../sound.h
speaker.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/i2s.h
speaker.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
speaker.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
speaker.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_map.h
speaker.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_patch.h
speaker.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdint.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/_stdint40.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/stdint.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/cdefs.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_types.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_types.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_stdint.h
speaker.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_stdint.h

../speaker.c: 
../speaker.h: 
../sound.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/i2s.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_map.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_patch.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdint.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/_stdint40.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/stdint.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/cdefs.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_types.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_types.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_stdint.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_stdint.h: 
