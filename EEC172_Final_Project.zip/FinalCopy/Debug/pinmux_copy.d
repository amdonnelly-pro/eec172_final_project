# FIXED

pinmux_copy.obj: ../pinmux_copy.c
pinmux_copy.obj: ../pinmux.h
pinmux_copy.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
pinmux_copy.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
pinmux_copy.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h
pinmux_copy.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h
pinmux_copy.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h
pinmux_copy.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h

../pinmux_copy.c: 
../pinmux.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
