# FIXED

pinmux_master.obj: ../pinmux_master.c
pinmux_master.obj: ../pinmux.h
pinmux_master.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
pinmux_master.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
pinmux_master.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h
pinmux_master.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h
pinmux_master.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h
pinmux_master.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h

../pinmux_master.c: 
../pinmux.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
