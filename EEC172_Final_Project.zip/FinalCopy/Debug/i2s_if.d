# FIXED

i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2s_if.c
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdio.h
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/_ti_config.h
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/linkage.h
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdarg.h
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_types.h
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/cdefs.h
i2s_if.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_types.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_mcasp.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_ints.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/debug.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_map.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_patch.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/udma.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/interrupt.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/uart.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/i2s.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/common.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2s_if.h
i2s_if.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/gpio_if.h

C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2s_if.c: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdio.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/_ti_config.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/linkage.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdarg.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_types.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/cdefs.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_mcasp.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_ints.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/debug.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_map.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_patch.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/udma.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/interrupt.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/uart.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/i2s.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/common.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2s_if.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/gpio_if.h: 
