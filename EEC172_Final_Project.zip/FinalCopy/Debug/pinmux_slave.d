# FIXED

pinmux_slave.obj: ../pinmux_slave.c
pinmux_slave.obj: ../pinmux.h
pinmux_slave.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
pinmux_slave.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
pinmux_slave.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h
pinmux_slave.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h
pinmux_slave.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h
pinmux_slave.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h

../pinmux_slave.c: 
../pinmux.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
