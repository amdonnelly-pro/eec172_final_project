################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../cc3200v1p32.cmd 

C_SRCS += \
../Adafruit_GFX.c \
../Adafruit_OLED.c \
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/gpio_if.c \
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2c_if.c \
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2s_if.c \
../main.c \
../oled_test.c \
../pinmux.c \
../speaker.c \
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/startup_ccs.c \
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/uart_if.c 

C_DEPS += \
./Adafruit_GFX.d \
./Adafruit_OLED.d \
./gpio_if.d \
./i2c_if.d \
./i2s_if.d \
./main.d \
./oled_test.d \
./pinmux.d \
./speaker.d \
./startup_ccs.d \
./uart_if.d 

OBJS += \
./Adafruit_GFX.obj \
./Adafruit_OLED.obj \
./gpio_if.obj \
./i2c_if.obj \
./i2s_if.obj \
./main.obj \
./oled_test.obj \
./pinmux.obj \
./speaker.obj \
./startup_ccs.obj \
./uart_if.obj 

OBJS__QUOTED += \
"Adafruit_GFX.obj" \
"Adafruit_OLED.obj" \
"gpio_if.obj" \
"i2c_if.obj" \
"i2s_if.obj" \
"main.obj" \
"oled_test.obj" \
"pinmux.obj" \
"speaker.obj" \
"startup_ccs.obj" \
"uart_if.obj" 

C_DEPS__QUOTED += \
"Adafruit_GFX.d" \
"Adafruit_OLED.d" \
"gpio_if.d" \
"i2c_if.d" \
"i2s_if.d" \
"main.d" \
"oled_test.d" \
"pinmux.d" \
"speaker.d" \
"startup_ccs.d" \
"uart_if.d" 

C_SRCS__QUOTED += \
"../Adafruit_GFX.c" \
"../Adafruit_OLED.c" \
"C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/gpio_if.c" \
"C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2c_if.c" \
"C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2s_if.c" \
"../main.c" \
"../oled_test.c" \
"../pinmux.c" \
"../speaker.c" \
"C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/startup_ccs.c" \
"C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/uart_if.c" 


