# FIXED

main.obj: ../main.c
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdio.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/_ti_config.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/linkage.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdarg.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_types.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/cdefs.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_types.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/string.h
main.obj: C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdlib.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_ints.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_common_reg.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_map.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_patch.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/interrupt.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/utils.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/uart.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/uart_if.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2c_if.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/i2s.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_apps_rcm.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h
main.obj: ../oled_test.h
main.obj: ../Adafruit_SSD1351.h
main.obj: ../Adafruit_GFX.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/spi.h
main.obj: C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/gpio_if.h
main.obj: ../pinmux.h
main.obj: ../speaker.h

../main.c: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdio.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/_ti_config.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/linkage.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdarg.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/_types.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/sys/cdefs.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/machine/_types.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/string.h: 
C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include/stdlib.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_ints.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_common_reg.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_map.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/rom_patch.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/interrupt.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/utils.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/uart.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/uart_if.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/i2c_if.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/i2s.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_apps_rcm.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h: 
../oled_test.h: 
../Adafruit_SSD1351.h: 
../Adafruit_GFX.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib/spi.h: 
C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common/gpio_if.h: 
../pinmux.h: 
../speaker.h: 
