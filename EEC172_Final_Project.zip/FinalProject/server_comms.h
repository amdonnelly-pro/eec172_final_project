#ifndef SERVER_COMMS_H_
#define SERVER_COMMS_H_

#include "coordinates.h"

// UPDATE THIS
#define DATE                6    /* Current Date */
#define MONTH               5     /* Month 1-12 */
#define YEAR                2026  /* Current year */
#define HOUR                11    /* Time - hours */
#define MINUTE              21    /* Time - minutes */
#define SECOND              0     /* Time - seconds */


#define SERVER_NAME           "a2bivyo33tlk0q-ats.iot.us-east-1.amazonaws.com" // I've updated 5/24
#define GOOGLE_DST_PORT       8443

int set_time();
int http_post(int iTLSSockID, char input_x[100], char input_y[100]);
void parse_coordinates(const char *json_string, Coordinates_t *coords);
int http_get(int iTLSSockID, Coordinates_t *coords);

#endif
