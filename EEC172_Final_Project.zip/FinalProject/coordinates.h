#ifndef COORDINATES_H
#define COORDINATES_H

typedef struct {
  double x;
  double y;
} Coordinates_t;

#endif
