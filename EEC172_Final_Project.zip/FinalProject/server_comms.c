#include <stdio.h>
#include <string.h>
#include "simplelink.h"
#include "hw_types.h"
#include "hw_ints.h"
#include "rom.h"
#include "rom_map.h"
#include "interrupt.h"
#include "prcm.h"
#include "utils.h"
#include "uart.h"
#include "pinmux.h"
#include "gpio_if.h"
#include "common.h"
#include "uart_if.h"
#include "utils/network_utils.h"
#include "coordinates.h"
#include "server_comms.h"


#define POSTHEADER "POST /things/EEC172_final_project_walker/shadow?name=shadow_name_for_172 HTTP/1.1\r\n" // Updated 5/24
#define GETHEADER "GET /things/EEC172_final_project_walker/shadow?name=shadow_name_for_172 HTTP/1.1\r\n"   // Update 5/24
#define HOSTHEADER "Host: a2bivyo33tlk0q-ats.iot.us-east-1.amazonaws.com\r\n"  // I've update 5/24
#define CHEADER "Connection: Keep-Alive\r\n"
#define CTHEADER "Content-Type: application/json; charset=utf-8\r\n"
#define CLHEADER1 "Content-Length: "
#define CLHEADER2 "\r\n\r\n"



int set_time() {
    long retVal;
    g_time.tm_day = DATE;
    g_time.tm_mon = MONTH;
    g_time.tm_year = YEAR;
    g_time.tm_sec = SECOND;
    g_time.tm_hour = HOUR;
    g_time.tm_min = MINUTE;

    retVal = sl_DevSet(SL_DEVICE_GENERAL_CONFIGURATION,
                          SL_DEVICE_GENERAL_CONFIGURATION_DATE_TIME,
                          sizeof(SlDateTime),(unsigned char *)(&g_time));

    ASSERT_ON_ERROR(retVal);
    return SUCCESS;
}

int http_post(int iTLSSockID, char input_x[100], char input_y[100]){
    char acSendBuff[1024]; // Increased size just in case
    char cCLLength[20];
    char bodyBuf[512];
    char* pcBufHeaders;
    int lRetVal = 0;

    // This will cook the x and y into a JSON string for the body of the POST request
    snprintf(bodyBuf, sizeof(bodyBuf),
             "{\"state\":{\"desired\":{\"x\":\"%s\",\"y\":\"%s\"}}}",
             input_x, input_y);

    int totalBodyLength = strlen(bodyBuf);

    // 2. Build HEADERS
    pcBufHeaders = acSendBuff;

    strcpy(pcBufHeaders, POSTHEADER);
    pcBufHeaders += strlen(POSTHEADER);

    strcpy(pcBufHeaders, HOSTHEADER);
    pcBufHeaders += strlen(HOSTHEADER);

    strcpy(pcBufHeaders, CHEADER);
    pcBufHeaders += strlen(CHEADER);

    strcpy(pcBufHeaders, CTHEADER);
    pcBufHeaders += strlen(CTHEADER);

    // 3. Add Content-Length
    strcpy(pcBufHeaders, CLHEADER1);
    pcBufHeaders += strlen(CLHEADER1);

    sprintf(cCLLength, "%d", totalBodyLength);
    strcpy(pcBufHeaders, cCLLength);
    pcBufHeaders += strlen(cCLLength);

    strcpy(pcBufHeaders, "\r\n\r\n");
    pcBufHeaders += 4;

    strcpy(pcBufHeaders, bodyBuf);

    // Send the whole thing
    lRetVal = sl_Send(iTLSSockID, acSendBuff, strlen(acSendBuff), 0);
    if(lRetVal < 0) {
        UART_PRINT("POST failed. Error Number: %i\n\r",lRetVal);
        sl_Close(iTLSSockID);
        GPIO_IF_LedOn(MCU_RED_LED_GPIO);
        return lRetVal;
    }
}

void parse_coordinates(const char *json_string, Coordinates_t *coords){
    const char *x_key = strstr(json_string, "\"x\":");
    const char *y_key = strstr(json_string, "\"y\":");

    if (x_key != NULL) {
        const char *x_value_start = x_key + 4; // move to start of x value
        sscanf(x_value_start, "%lf", &coords->x);
    }

    if (y_key != NULL) {
        const char * y_value_start = y_key + 4;
        sscanf(y_value_start, "%lf", &coords->y);
    }
}

int http_get(int iTLSSockID, Coordinates_t *coords){
    char acSendBuff[512];
    char acRecvbuff[1460];
    char* pcBufHeaders;
    int lRetVal = 0;

    pcBufHeaders = acSendBuff;
    strcpy(pcBufHeaders, GETHEADER);
    pcBufHeaders += strlen(GETHEADER);
    strcpy(pcBufHeaders, HOSTHEADER);
    pcBufHeaders += strlen(HOSTHEADER);
    strcpy(pcBufHeaders, CHEADER);
    pcBufHeaders += strlen(CHEADER);
    strcpy(pcBufHeaders, "\r\n\r\n");

    UART_PRINT(acSendBuff);

    lRetVal = sl_Send(iTLSSockID, acSendBuff, strlen(acSendBuff), 0);
    if(lRetVal < 0) {
        UART_PRINT("GET failed. Error Number: %i\n\r",lRetVal);
        sl_Close(iTLSSockID);
        GPIO_IF_LedOn(MCU_RED_LED_GPIO);
        return lRetVal;
    }

    lRetVal = sl_Recv(iTLSSockID, &acRecvbuff[0], sizeof(acRecvbuff), 0);
    if(lRetVal < 0) {
        UART_PRINT("Received failed. Error Number: %i\n\r",lRetVal);
        GPIO_IF_LedOn(MCU_RED_LED_GPIO);
        return lRetVal;
    }
    else { // 2. Fixed the stray 'coordinates_t' typo right here
        acRecvbuff[lRetVal] = '\0'; // Note: indices are 0 to lRetVal-1, changed lRetVal+1 to lRetVal to avoid overflow
        UART_PRINT(acRecvbuff);
        UART_PRINT("\n\r\n\r");
    }

    parse_coordinates(acRecvbuff, coords);
    return 0;
}
