

Here are the include paths:
${CG_TOOL_ROOT}/include
${CC3200_SDK_ROOT}/driverlib
${CC3200_SDK_ROOT}/inc
${CC3200_SDK_ROOT}/example/common
${CC3200_SDK_ROOT}/simplelink/
${CC3200_SDK_ROOT}/simplelink/source
${CC3200_SDK_ROOT}/simplelink/include
${CC3200_SDK_ROOT}/simplelink_extlib/provisioninglib