################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
utils/%.obj: ../utils/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: ARM Compiler'
	"C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib -me --include_path="C:/TI/ccs930/ccs/tools/compiler/ti-cgt-arm_18.12.4.LTS/include" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/driverlib" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/inc" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/example/common" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/simplelink/" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/simplelink/source" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/simplelink/include" --include_path="C:/TI/CC3200SDK_1.4.0/cc3200-sdk/simplelink_extlib/provisioninglib" --define=cc3200 --abi=eabi --preproc_with_compile --preproc_dependency="utils/$(basename $(<F)).d_raw" --obj_directory="utils" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


