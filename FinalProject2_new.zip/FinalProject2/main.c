//*****************************************************************************
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "rom.h"
#include "rom_map.h"
#include "interrupt.h"
#include "prcm.h"
#include "utils.h"
#include "uart.h"
#include "uart_if.h"
#include "i2c_if.h"

// IMPORTED FROM LAB 2
#include "hw_apps_rcm.h"
#include "gpio.h"
#include "oled_test.h"
#include "Adafruit_SSD1351.h"
#include "Adafruit_GFX.h"

#include "spi.h"

// Common interface includes
#include "gpio_if.h"
#include "pinmux.h"

#include <math.h>
#include "map.h"
#include "stdint.h"
#include "utils/network_utils.h"
#include "server_comms.h"

#define APPLICATION_VERSION     "1.4.0"
#define APP_NAME                "Final Project"
#define UART_PRINT              Report
#define FOREVER                 1
#define CONSOLE                 UARTA0_BASE
#define FAILURE                 -1
#define SUCCESS                 0
#define RETERR_IF_TRUE(condition) {if(condition) return FAILURE;}
#define RET_IF_ERR(Func)          {int iRetVal = (Func); \
                                   if (SUCCESS != iRetVal) \
                                     return  iRetVal;}
#define MASTER_MODE  1
#define SPI_IF_BIT_RATE  100000
#define DEG_TO_RAD (M_PI / 180.0)
#define PIXELS_PER_METER 0.2


//*****************************************************************************
#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif
//*****************************************************************************
static void
BoardInit(void)
{
#ifndef USE_TIRTOS
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);
    PRCMCC3200MCUInit();
}


void Init_GPS_UART(void)
{
    MAP_UARTConfigSetExpClk(UARTA1_BASE, MAP_PRCMPeripheralClockGet(PRCM_UARTA1),
                            9600, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                            UART_CONFIG_PAR_NONE));

    MAP_UARTEnable(UARTA1_BASE);
}

char* parseSegment(char* start_pntr, char* buffer) {
    char* end_pntr = strstr(start_pntr, ",");
    int length = (int)(end_pntr - start_pntr);
    strncpy(buffer, start_pntr, length);
    buffer[length] = '\0';

    return end_pntr;
}

double nmeaToDecimal(const char *nmea)
{
    double value = atof(nmea);

    double degrees = floor(value / 100.0);
    double minutes = value - (degrees * 100.0);

    return degrees + minutes / 60.0;
}

void WorkerProgram() {
    Init_GPS_UART();

    while (1)
    {
        MAP_UtilsDelay(1000000);

        // Fetch lat, lng, coords from GPS module (UART communication)
        char buffer[128];
        int idx = 0;
        while (idx < 128) {
            if (MAP_UARTCharsAvail(UARTA1_BASE))
            {
                char c = MAP_UARTCharGet(UARTA1_BASE);
                if (c == '\n') {
                    buffer[idx] = '\0';
                    break;
                }
                buffer[idx] = c;
                idx++;
            }
            else
            {
                // Report("No data\r\n");
            }
        }
        Message("\nFull Message: \r\n");
        Message(buffer);

        char y[100];
        char dir1[100];
        char x[100];
        char dir2[100];


        // Find the first occurrence of sub in str
        char* result = strstr(buffer, "$GPRMC");

        if (result != NULL) {
            result = strstr(result, ",");
            int i;
            for (i = 0; i<2; i++) {
                result = strstr(result + 1, ",");
            }
            char* start_pntr = result + 1;
            char* end_pntr = parseSegment(start_pntr, y);
            end_pntr = parseSegment(end_pntr + 1, dir1);
            end_pntr = parseSegment(end_pntr + 1, x);
            end_pntr = parseSegment(end_pntr + 1, dir2);

            printf("Substring found!\n");
            printf("Full text from match: %s %s %s %s\n", y, dir1, x, dir2);

            double lat = nmeaToDecimal(y);
            if (strstr(dir1, "S") != NULL) {
                lat = lat * -1;
            }
            double lng = nmeaToDecimal(x);
            if (strstr(dir2, "W") != NULL) {
                lng = lng * -1;
            }

            long lRetVal = -1;
            char y_position[32];
            snprintf(y_position, sizeof(y_position), "%f", lat);

            char x_position[32];
            snprintf(x_position, sizeof(x_position), "%f", lng);

            http_post(lRetVal, x_position, y_position);
        } else {
            printf("Substring not found.\n");
        }
    }
}

void Init_OLED_SPI() {
    I2C_IF_Open(I2C_MASTER_MODE_FST);

    MAP_SPIReset(GSPI_BASE);

    // Configure SPI interface
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                           SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_0,
                           (SPI_SW_CTRL_CS |
                           SPI_4PIN_MODE |
                           SPI_TURBO_OFF |
                           SPI_CS_ACTIVEHIGH |
                           SPI_WL_8));

    // Enable SPI for communication
    MAP_SPIEnable(GSPI_BASE);

    Adafruit_Init();
}

void drawMap(void)
{
    int y;
    for (y = 0; y < MAP_HEIGHT; y++)
    {
        int x;
        for (x = 0; x < MAP_WIDTH; x++)
        {
            uint8_t gray =
                map[y * MAP_WIDTH + x];

            // Convert grayscale -> RGB565
            uint16_t color =
                ((gray & 0xF8) << 8) |
                ((gray & 0xFC) << 3) |
                (gray >> 3);

            drawPixel(x, y, color);
        }
    }
}

int latLngToScreenX(double userLng)
{
    return (int)(
        ((userLng - UPPER_LEFT_LNG) /
         (BOTTOM_RIGHT_LNG - UPPER_LEFT_LNG))
        * (WIDTH - 1)
    );
}

int latLngToScreenY(double userLat)
{
    return (int)(
        ((UPPER_LEFT_LAT - userLat) /
         (UPPER_LEFT_LAT - BOTTOM_RIGHT_LAT))
        * (HEIGHT - 1)
    );
}

void restoreMapPixel(int x, int y)
{
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT) {
        return;
    }

    uint8_t gray = map[y * WIDTH + x];

    uint16_t color = ((gray & 0xF8) << 8) |
                     ((gray & 0xFC) << 3) |
                     (gray >> 3);

    drawPixel(x, y, color);
}

void restoreCircleArea(int centerX, int centerY, int radius)
{
    int x;
    int y;

    for (y = centerY - radius; y <= centerY + radius; y++)
    {
        for (x = centerX - radius; x <= centerX + radius; x++)
        {
            restoreMapPixel(x, y);
        }
    }
}

long InitAWSConnection() {
    // initialize global default app configuration
    g_app_config.host = SERVER_NAME;
    g_app_config.port = GOOGLE_DST_PORT;

    long lRetVal;
    lRetVal = connectToAccessPoint();
    lRetVal = set_time();
    if(lRetVal < 0) {
        UART_PRINT("Unable to set time in the device");
        LOOP_FOREVER();
    }

    lRetVal = tls_connect();
    if(lRetVal < 0) {
        ERR_PRINT(lRetVal);
        return -1;
    }
    return lRetVal;

}

//*****************************************************************************
void main()
{
    BoardInit();
    if (MASTER_MODE) {
        PinMuxConfigMaster();
    } else {
        PinMuxConfigSlave();
    }


    InitTerm();
    ClearTerm();

    Report("Debugging via print statements !\n\r");

    long lRetVal = InitAWSConnection();

    if (MASTER_MODE) {
        Init_OLED_SPI();

        drawMap();

        double userLat = 38.537593;
        double userLng = -121.754321;
        int screenX = latLngToScreenX(userLng);
        int screenY = latLngToScreenY(userLat);
        fillCircle(screenX, screenY, 3, RED);

        http_post_temp(lRetVal, 2);

        while (1)
        {

            unsigned long sw3 = GPIOPinRead(GPIOA1_BASE, GPIO_PIN_5);
            unsigned long sw2 = GPIOPinRead(GPIOA2_BASE, GPIO_PIN_6);

            if (sw2 != 0) {
                    Message("\nSwitch 2 pressed\n\r");
                    http_post_temp(lRetVal, 2);
            }

            if (sw3 != 0) {
                    Message("\nSwitch 3 pressed\n\r");
                    http_post_temp(lRetVal, 3);
            }


            Coordinates_t coords;
            http_get(lRetVal, &coords);


            UART_PRINT("Received coordinates: x = %f, y = %f, hotCold= %d \n\r", coords.x, coords.y, coords.hotCold);
            UART_PRINT("Screen: x = %d, y = %d", screenX, screenY);

            restoreCircleArea(screenX, screenY, 3);

            screenX = latLngToScreenX(coords.x);
            screenY = latLngToScreenY(coords.y);

            fillCircle(screenX, screenY, 3, RED);

            MAP_UtilsDelay(800000);
        }
    } else {
        WorkerProgram();
    }
}
