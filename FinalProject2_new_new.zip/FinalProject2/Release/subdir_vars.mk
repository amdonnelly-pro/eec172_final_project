################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../cc3200v1p32.cmd 

C_SRCS += \
../Adafruit_GFX.c \
../Adafruit_OLED.c \
C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/gpio_if.c \
C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/i2c_if.c \
../main.c \
C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/network_common.c \
../oled_test.c \
../pinmux.c \
../pinmux_master.c \
../pinmux_slave.c \
../server_comms.c \
C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/startup_ccs.c \
../uart_if.c 

C_DEPS += \
./Adafruit_GFX.d \
./Adafruit_OLED.d \
./gpio_if.d \
./i2c_if.d \
./main.d \
./network_common.d \
./oled_test.d \
./pinmux.d \
./pinmux_master.d \
./pinmux_slave.d \
./server_comms.d \
./startup_ccs.d \
./uart_if.d 

OBJS += \
./Adafruit_GFX.obj \
./Adafruit_OLED.obj \
./gpio_if.obj \
./i2c_if.obj \
./main.obj \
./network_common.obj \
./oled_test.obj \
./pinmux.obj \
./pinmux_master.obj \
./pinmux_slave.obj \
./server_comms.obj \
./startup_ccs.obj \
./uart_if.obj 

OBJS__QUOTED += \
"Adafruit_GFX.obj" \
"Adafruit_OLED.obj" \
"gpio_if.obj" \
"i2c_if.obj" \
"main.obj" \
"network_common.obj" \
"oled_test.obj" \
"pinmux.obj" \
"pinmux_master.obj" \
"pinmux_slave.obj" \
"server_comms.obj" \
"startup_ccs.obj" \
"uart_if.obj" 

C_DEPS__QUOTED += \
"Adafruit_GFX.d" \
"Adafruit_OLED.d" \
"gpio_if.d" \
"i2c_if.d" \
"main.d" \
"network_common.d" \
"oled_test.d" \
"pinmux.d" \
"pinmux_master.d" \
"pinmux_slave.d" \
"server_comms.d" \
"startup_ccs.d" \
"uart_if.d" 

C_SRCS__QUOTED += \
"../Adafruit_GFX.c" \
"../Adafruit_OLED.c" \
"C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/gpio_if.c" \
"C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/i2c_if.c" \
"../main.c" \
"C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/network_common.c" \
"../oled_test.c" \
"../pinmux.c" \
"../pinmux_master.c" \
"../pinmux_slave.c" \
"../server_comms.c" \
"C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/startup_ccs.c" \
"../uart_if.c" 


