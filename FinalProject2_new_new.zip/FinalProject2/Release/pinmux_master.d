# FIXED

pinmux_master.obj: ../pinmux_master.c
pinmux_master.obj: ../pinmux.h
pinmux_master.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_types.h
pinmux_master.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_memmap.h
pinmux_master.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_gpio.h
pinmux_master.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/pin.h
pinmux_master.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/gpio.h
pinmux_master.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/prcm.h

../pinmux_master.c:

../pinmux.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_types.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_memmap.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_gpio.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/pin.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/gpio.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/prcm.h:

