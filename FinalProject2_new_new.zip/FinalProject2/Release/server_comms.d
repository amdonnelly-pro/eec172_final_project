# FIXED

server_comms.obj: ../server_comms.c
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/string.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/xlocale/_string.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/simplelink.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/user.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/cc_pal.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink_extlib/provisioninglib/provisioning_api.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/simplelink.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/source/objInclusion.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/trace.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/fs.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/socket.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/netapp.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/wlan.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/device.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/netcfg.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/wlan_rx_filters.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/source/nonos.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_types.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_ints.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_map.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_patch.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/interrupt.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/prcm.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/utils.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/uart.h
server_comms.obj: ../pinmux.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/gpio_if.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/common.h
server_comms.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/uart_if.h
server_comms.obj: ../utils/network_utils.h
server_comms.obj: ../coordinates.h
server_comms.obj: ../server_comms.h
server_comms.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdlib.h

../server_comms.c:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/xlocale/_string.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/simplelink.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/user.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/cc_pal.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink_extlib/provisioninglib/provisioning_api.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/simplelink.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/source/objInclusion.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/trace.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/fs.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/socket.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/netapp.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/wlan.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/device.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/netcfg.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/include/wlan_rx_filters.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/simplelink/source/nonos.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_types.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_ints.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_map.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_patch.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/interrupt.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/prcm.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/utils.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/uart.h:

../pinmux.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/gpio_if.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/common.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/uart_if.h:

../utils/network_utils.h:

../coordinates.h:

../server_comms.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdlib.h:

