#ifndef COORDINATES_H
#define COORDINATES_H

typedef struct {
  double x;
  double y;
  int hotCold;
} Coordinates_t;

#endif
